app.controller('Departments', ['$http', 'common',
function($http, common) {
    
    console.log("Departments controller starting");
    
    var self = this;
    self.confirm = common.confirm;
    
    self.department = {};	
    console.log('yyyyy');

    self.refresh = function() {
			$http.get('/db/departments/').then(
				function(response) {
					self.departments = response.data;
				},
				function(errResponse) {
					self.departments = [];
				}
			);
		}
    
    self.refresh();
    
    self.insert = function() {
        console.log('ctrl.insert(), ' + JSON.stringify(self.department));
        $http.post('/db/departments/json', self.department).then(
            function(response) {
                self.refresh();
            },
            function(errResponse) {
                console.log(JSON.stringify(errResponse));
            }
        );
		console.log('pyrtu');
    }
	console.log('xxxxx');
    self.edit = function(id = '') {
		//console.log(JSON.stringify(self.departments.length));
        if(id) {
            $http.get('/db/departments/' + id).then(
                function(response) {
                    self.department = response.data[0];
                    $("#editDepartment").modal();			
                },
                function(errResponse) {}
            );
        } else {
            self.department = {};
            $("#editDepartment").modal();
        }
		
		//var str=JSON.stringify(self.departments.length);
		//var lint=parseInt(str);
		//console.log(JSON.stringify(id));

		//for (var i=0; i <lint; i++){
		//	
		//}
		//console.log('trololo');
		//console.log(self.departments[1].latitude);
		//console.log(self.departments[1].longitude);
		//if (latitude && longitude)
		//{
			//console.log('pyrtu');
			
			//var map = new google.maps.Map(document.getElementById('map'), {

			//console.log('pyrtuuu');
			//var marker = new google.maps.Marker({
			//	console.log('pyrtuuu');
			//position:{lat:51.779185,lng:19.455983},
			//map:map,
			//icon:'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png'
			//});
			//}
		 
			
		//}
		
		//
		
		//
		
    }
	self.getCoords = function() {
		var coords = self.department;
		coords.latitude = $("#latitude").val();
        coords.longitude = $("#longitude").val();
		console.log('Coords');
		console.log(coords.latitude);
		console.log(coords.longitude);
		
		// Add marker
		
	}
    
    self.editSubmit = function() {
        var departmentEdited = self.department;
        departmentEdited.latitude = $("#latitude").val();
        departmentEdited.longitude = $("#longitude").val();
        console.log('ctrl.editSubmit()', departmentEdited);
        if(departmentEdited._id) {
            $http.put('/db/departments/' + departmentEdited._id, departmentEdited).then(
                function(response) {
                    console.log('response', response);
                    self.refresh();
                },
                function(errResponse) {
                    console.log(JSON.stringify(errResponse));
                }
            );
        } else {
            $http.post('/db/departments/json', departmentEdited).then(
                function(response) {
                    self.refresh();
                },
                function(errResponse) {
                    console.log(JSON.stringify(errResponse));
                }
            );				
        }
        $('#editDepartment').modal('hide');
    }
	/*
     self.confirmRemove = function(department) {
         $('#editDepartment').modal('hide');
         common.confirm.text = 'Are you sure to delete a department "' + self.department.name '" ?';
         common.confirm.action = self.remove;
         $("#confirmDialog").modal();
     }
    
     self.remove = function() {
         $("#confirmDialog").modal('hide');
         if(self.department._id) {
             $http.delete('/db/departments/' + self.department._id).then(
                 function(response) {
                     self.refresh();
                 },
                 function(errResponse) {
                     console.log(JSON.stringify(errResponse));
                }
            );
             $('#editDepartment').modal('hide');
         }
     }
    */
}
]);